import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        count: 14
    },
    getters: {
        count: (state, getters) => (id) => {
            // если есть id
            return state.count;// /id

            // если нет
            //return state.count
        }
    },
    mutations: {
        inc(state, i) {
            // если есть i
            // state.count *= i;

            // если нет
            state.count++;
        },
        dec(state, i) {
            // если есть i
            //state.count /= i;

            // если нет
            state.count--;
        }
    },
    actions: {
        send(context, i) {
            context.commit('dec', i);
        }
    },
    modules: {
        submodule: {
            namespaced: true,
            state: {
                count: 15
            },
            getters: {
                count(state, getters, rootState, rootGetters) {
                    return state.count;
                }
            },
            mutations: {
                inc(state) {
                    state.count += 2;
                }
            },
            actions: {
                globalInc({ dispatch, commit, getters, rootGetters }) {
                    commit('inc', null, {root: true})
                }
            }
        }
    }
});
