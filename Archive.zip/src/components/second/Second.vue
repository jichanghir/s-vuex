<template lang="pug">
    div
        div {{ count }}
        button(@click="globalInc(2)") +
        button(@click="dec(2)") -
        button(@click="send(2)") send
</template>

<script>
import { createNamespacedHelpers } from 'vuex';
const { mapState, mapGetters, mapMutations, mapActions } = createNamespacedHelpers('submodule');

//import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';

export default {
    props: {},
    data(){
        return {}
    },
    computed: {
        ...mapGetters(['count'])
    },
    methods: {
        ...mapMutations([
            'inc',
            'dec'
        ]),
        ...mapActions([
            'globalInc',
            'send'
        ])
    },
    components: {}
}
</script>
