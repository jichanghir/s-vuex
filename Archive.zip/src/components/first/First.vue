<template lang="pug">
    div
        div {{ count(2) }}
        button(@click="inc(2)") +
        button(@click="dec(2)") -
        button(@click="send(2)") send
</template>

<script>

export default {
    props: {},
    data(){
        return {}
    },
    computed: {
        count() {
            // или так
            return this.$store.getters.count

            // или так , если сами должны передавать
            // return this.$store.getters.count(2)
        }
    },
    methods: {
        inc(param) {
            this.$store.commit('inc', param)
        },
        dec(param) {
            this.$store.commit('dec', param)
        },
        send(param) {
            this.$store.dispatch('send', 3)
        }
    },
    components: {}
}
</script>

